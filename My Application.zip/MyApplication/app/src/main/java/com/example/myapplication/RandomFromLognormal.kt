package com.example.myapplication

import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sqrt

class RandomFromLognormal {

    fun lognormal(mean: Double?, std: Double?): Double? {
        if(mean == null || std == null){
            return null
        }
        val x = (0..100).random() + 0.0
        val y = exp(-(ln(x) - mean).pow(2) / (2 * std)) / (x * sqrt(std) * sqrt(2 * Math.PI))
        return y
    }
}