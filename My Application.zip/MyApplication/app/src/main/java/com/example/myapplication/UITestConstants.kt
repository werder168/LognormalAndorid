package com.example.myapplication

const val GET_RANDOM_NUM = "get_random_num"

const val RANDOM_NUMBER_RES = "random_number_res"

const val MEAN_VAL = "mean_val"

const val VARIANCE_VALUE = "variance_value"